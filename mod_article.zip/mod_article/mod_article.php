<?php
/**
 * @package     Joomla.Tutorials
 * Created by JetBrains PhpStorm.
 * @subpackage  Module
 * @copyright   (C) 2012 http://jomla-code.ru
 * @license     License GNU General Public License version 2 or later; see LICENSE.txt
 * User: satoru
 * Date: 11.11.13
 * Time: 15:01
 * To change this template use File | Settings | File Templates.
 */

defined('_JEXEC') or die('Restricted access');

$db = JFactory::getDbo();
$query = $db->getQuery(true);
$query->select('title');
$query->from('#__content');
$db->setQuery($query);
$list = $db->loadObjectList();

foreach ($list as $item) {
    echo "</br>";
    echo $item->title;
}

?>